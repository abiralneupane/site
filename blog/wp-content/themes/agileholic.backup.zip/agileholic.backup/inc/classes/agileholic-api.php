<?php
class AGILEHOLIC_API{
	function __construct(){
		
	}
}