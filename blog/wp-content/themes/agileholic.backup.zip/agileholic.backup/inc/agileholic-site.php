<?php

class AGILEHOLIC_SITE{
	function __construct(){
		add_action( 'init', array($this, 'register_posts') );
		add_action( 'init', array($this, 'register_tax') );

		add_image_size( 'profile-thumb', 232, 232, true );
	}

	public function register_posts(){
		new AGILEHOLIC_POSTTYPES('ag-process', 'Process', 'Processes', array('title','editor'));
		new AGILEHOLIC_POSTTYPES('ag-employment', 'Employment', 'Employments', array('title','editor'));
		new AGILEHOLIC_POSTTYPES('ag-education', 'Education', 'Educations', array('title','editor'));
		new AGILEHOLIC_POSTTYPES('ag-skills', 'Skill', 'Skills', array('title'));
		new AGILEHOLIC_POSTTYPES('ag-hobbies', 'Hobby', 'Hobbies', array('title'));
		new AGILEHOLIC_POSTTYPES('ag-services', 'Service', 'Services', array('title','editor'));
		new AGILEHOLIC_POSTTYPES('ag-testimonials', 'Testimonial', 'Testimonials', array('title','editor'));
		new AGILEHOLIC_POSTTYPES('ag-portfolio', 'Portfolio', 'Portfolios', array('title','editor', 'excerpt','post-thumbnail'));
		new AGILEHOLIC_POSTTYPES('ag-language', 'Language', 'Languages', array('title'));
	}

	public function register_tax(){
		new AGILEHOLIC_TAX('ag-skills-types','ag-skills','Type', 'Types' );
		new AGILEHOLIC_TAX('ag-portfolio-types','ag-portfolio','Type', 'Types' );	
	}
}


$GLOBALS['ag_site'] = new AGILEHOLIC_SITE();